import { useState } from "react";
import Header from "./components/Header";
import TaskForm from "./components/TaskForm";
import TaskList from "./components/TaskList";
import "./App.css";
function App() {
  const [tasks, setTasks] = useState([
    {
      id: 1,
      title: "Estudar componentes React",
      completed: false
    },
    {
      id: 2,
      title: "Criar um componente reutilizável",
      completed: true
    }
  ]);
  function addTask(title) {
    const newTask = {
      id: Date.now(),
      title,
      completed: false
    };
    setTasks((currentTasks) => [
      ...currentTasks,
      newTask
    ]);
  }
  function toggleTask(id) {
    setTasks((currentTasks) =>
      currentTasks.map((task) =>
        task.id === id
          ? { ...task, completed: !task.completed }
          : task
      )
    );
  }
  function deleteTask(id) {
    setTasks((currentTasks) =>
      currentTasks.filter((task) => task.id !== id)
    );
  }
  return (
    <main className="app">
      <Header />
      <TaskForm onAdd={addTask} />
      <TaskList
        tasks={tasks}
        onToggle={toggleTask}
        onDelete={deleteTask}
      />
    </main>
  );
}
export default App;