import TaskCard from "./TaskCard";
function TaskList({ tasks, onToggle, onDelete }) {
    if (tasks.length === 0) {
        return (
            <p className="empty">
                Nenhuma tarefa cadastrada.
            </p>
        );
    }
    return (
        <section className="task-list">
            {tasks.map((task) => (
                <TaskCard
                    key={task.id}
                    task={task}
                    onToggle={onToggle}
                    onDelete={onDelete}
                />
            ))}
        </section>
    );
}
export default TaskList;