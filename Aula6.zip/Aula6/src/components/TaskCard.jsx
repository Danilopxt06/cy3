import Button from "./Button";

function TaskCard({task, onToggle, onDelete}){
    return(
        <article className={`task-card, ${task.completed ? "completed": ""}`}>

        </article>
    )
}
export default TaskCard;