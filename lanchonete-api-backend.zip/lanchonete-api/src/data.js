// Dados iniciais do cardápio (os alunos podem editar, adicionar ou remover via API)
const produtos = [
  {
    id: 1,
    nome: "X-Burger",
    preco: 18.00,
    categoria: "Hambúrgueres",
    descricao: "Pão brioche selado na manteiga, hambúrguer artesanal 150g, queijo prato derretido, alface americana, tomate e maionese especial da casa.",
    imagem: "/images/x-burger.svg",
    disponivel: true
  },
  {
    id: 2,
    nome: "X-Bacon",
    preco: 23.00,
    categoria: "Hambúrgueres",
    descricao: "Pão brioche, dois hambúrgueres smash 100g, queijo cheddar cremoso, fatias crocantes de bacon defumado e molho barbecue.",
    imagem: "/images/x-bacon.svg",
    disponivel: true
  },
  {
    id: 3,
    nome: "Batata Frita",
    preco: 12.00,
    categoria: "Porções",
    descricao: "Porção generosa (300g) de batatas palito selecionadas, fritas até ficarem douradas e crocantes, finalizadas com sal e páprica.",
    imagem: "/images/batata-frita.svg",
    disponivel: true
  },
  {
    id: 4,
    nome: "Anéis de Cebola",
    preco: 15.00,
    categoria: "Porções",
    descricao: "12 unidades de anéis de cebola empanados na farinha panko super crocante, acompanhados de molho rosé.",
    imagem: "/images/onion-rings.svg",
    disponivel: true
  },
  {
    id: 5,
    nome: "Refrigerante",
    preco: 7.00,
    categoria: "Bebidas",
    descricao: "Lata 350ml bem gelada (Coca-Cola, Guaraná Antarctica ou Sprite) servida com copo, gelo e rodela de limão.",
    imagem: "/images/refrigerante.svg",
    disponivel: true
  },
  {
    id: 6,
    nome: "Milkshake de Morango",
    preco: 16.50,
    categoria: "Sobremesas",
    descricao: "Copo 400ml batido com sorvete artesanal de creme, calda natural de morango e finalizado com chantilly.",
    imagem: "/images/milkshake.svg",
    disponivel: true
  }
];

// Lista em memória para armazenar os pedidos realizados
const pedidos = [];

module.exports = { produtos, pedidos };
