const express = require('express');
const cors = require('cors');
const path = require('path');
const { produtos, pedidos } = require('./data');

const app = express();
const PORT = process.env.PORT || 3001;

// Middlewares
app.use(cors()); // Libera acesso para o Front-end React (Vite)
app.use(express.json()); // Permite receber JSON no corpo das requisições

// Servir as imagens estáticas da pasta public/images
app.use('/images', express.static(path.join(__dirname, '../public/images')));

// Função auxiliar para montar a URL completa da imagem
function formatarProduto(req, produto) {
  const baseUrl = `${req.protocol}://${req.get('host')}`;
  return {
    ...produto,
    imagemUrl: produto.imagem.startsWith('http')
      ? produto.imagem
      : `${baseUrl}${produto.imagem}`
  };
}

// ==========================================
// ROTAS DO CARDÁPIO (PRODUTOS)
// ==========================================

// 1. Listar todos os produtos (com filtro opcional por categoria ou busca)
app.get('/api/produtos', (req, res) => {
  const { categoria, busca } = req.query;
  let resultado = produtos;

  if (categoria && categoria !== 'Todos') {
    resultado = resultado.filter(
      (p) => p.categoria.toLowerCase() === categoria.toLowerCase()
    );
  }

  if (busca) {
    resultado = resultado.filter((p) =>
      p.nome.toLowerCase().includes(busca.toLowerCase())
    );
  }

  const resposta = resultado.map((p) => formatarProduto(req, p));
  res.json(resposta);
});

// 2. Buscar um produto específico por ID
app.get('/api/produtos/:id', (req, res) => {
  const id = Number(req.params.id);
  const produto = produtos.find((p) => p.id === id);

  if (!produto) {
    return res.status(404).json({ erro: 'Produto não encontrado.' });
  }

  res.json(formatarProduto(req, produto));
});

// 3. Cadastrar novo produto no cardápio
app.post('/api/produtos', (req, res) => {
  const { nome, preco, categoria, descricao, imagem, disponivel } = req.body;

  if (!nome || preco === undefined || !categoria || !descricao) {
    return res.status(400).json({
      erro: 'Campos obrigatórios: nome, preco, categoria e descricao.'
    });
  }

  const novoProduto = {
    id: produtos.length > 0 ? Math.max(...produtos.map((p) => p.id)) + 1 : 1,
    nome,
    preco: Number(preco),
    categoria,
    descricao,
    imagem: imagem || '/images/x-burger.svg',
    disponivel: disponivel !== undefined ? Boolean(disponivel) : true
  };

  produtos.push(novoProduto);
  res.status(201).json(formatarProduto(req, novoProduto));
});

// ==========================================
// ROTAS DE PEDIDOS (POS / COZINHA)
// ==========================================

// 4. Listar todos os pedidos (com filtro opcional por status)
app.get('/api/pedidos', (req, res) => {
  const { status } = req.query;
  if (status && status !== 'Todos') {
    const filtrados = pedidos.filter(
      (ped) => ped.status.toLowerCase() === status.toLowerCase()
    );
    return res.json(filtrados);
  }
  res.json(pedidos);
});

// 5. Registrar um novo pedido
app.post('/api/pedidos', (req, res) => {
  const { cliente, itens } = req.body;

  if (!cliente || !Array.isArray(itens) || itens.length === 0) {
    return res.status(400).json({
      erro: 'Informe o nome do cliente e ao menos 1 item no pedido.'
    });
  }

  // Calcula o total no back-end para garantir segurança
  const total = itens.reduce(
    (acc, item) => acc + Number(item.preco) * Number(item.quantidade),
    0
  );

  const novoPedido = {
    numero: pedidos.length + 101, // Ex: Pedido #101, #102...
    cliente,
    itens,
    total: Number(total.toFixed(2)),
    dataHora: new Date().toLocaleString('pt-BR'),
    status: 'Recebido' // Status inicial: Recebido -> Preparando -> Pronto -> Entregue
  };

  pedidos.unshift(novoPedido); // Adiciona no topo da fila
  res.status(201).json(novoPedido);
});

// 6. Atualizar o status de um pedido
app.patch('/api/pedidos/:numero/status', (req, res) => {
  const numero = Number(req.params.numero);
  const { status } = req.body;

  const statusValidos = ['Recebido', 'Preparando', 'Pronto', 'Entregue'];
  if (!statusValidos.includes(status)) {
    return res.status(400).json({
      erro: `Status inválido. Use um dos seguintes: ${statusValidos.join(', ')}`
    });
  }

  const pedido = pedidos.find((p) => p.numero === numero);
  if (!pedido) {
    return res.status(404).json({ erro: 'Pedido não encontrado.' });
  }

  pedido.status = status;
  res.json(pedido);
});

app.listen(PORT, () => {
  console.log(`🍔 API da Lanchonete rodando em http://localhost:${PORT}`);
  console.log(`📋 Cardápio disponível em: http://localhost:${PORT}/api/produtos`);
  console.log(`🧾 Pedidos disponíveis em: http://localhost:${PORT}/api/pedidos`);
});
