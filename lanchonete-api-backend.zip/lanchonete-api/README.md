# 🍔 API da Lanchonete (Back-end Node.js + Express)

API RESTful didática criada para alimentar o front-end React (Vite) do sistema de pedidos da lanchonete.

## 🚀 Como rodar o projeto

1. Abra o terminal dentro da pasta `lanchonete-api`.
2. Instale as dependências:
   ```bash
   npm install
   ```
3. Inicie o servidor:
   ```bash
   npm run dev
   ```
4. A API estará rodando em `http://localhost:3001`.

## 📌 Endpoints Disponíveis

- `GET /api/produtos` — Lista todos os produtos do cardápio com imagem, nome, preço, categoria e descrição dos ingredientes.
  - Filtros opcionais: `?categoria=Hambúrgueres` ou `?busca=bacon`
- `POST /api/produtos` — Cadastra um novo item no cardápio.
- `GET /api/pedidos` — Lista todos os pedidos registrados.
- `POST /api/pedidos` — Registra um novo pedido (`{ cliente, itens }`).
- `PATCH /api/pedidos/:numero/status` — Atualiza o status do pedido (`Recebido`, `Preparando`, `Pronto`, `Entregue`).
